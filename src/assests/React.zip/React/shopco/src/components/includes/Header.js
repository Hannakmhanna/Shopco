import React from 'react';
import styled from 'styled-components';
import arrowIcon from '../../assests/Vector (4).svg';
import cartIcon from '../../assests/Frame (1).svg';
import signupIcon from '../../assests/Frame.svg';
import searchIcon from '../../assests/Frame (2).svg';

function Header() {
  return (
    <HeaderWrapper>
      <Logo>SHOP.CO</Logo>
      <Nav>
        <ul>
          <li>
            <a href="#shop">Shop</a>
            <img src={arrowIcon} alt="arrow" style={{ width: "10px", height: "10px" }} />
          </li>
          <li><a href="#on-sale">On Sale</a></li>
          <li><a href="#new-arrivals">New Arrivals</a></li>
          <li><a href="#brands">Brands</a></li>
        </ul>
      </Nav>
      <SearchBar>
        <SearchWrapper>
          <SearchIcon src={searchIcon} alt="search" />
          <SearchBarInput type="text" placeholder="Search for products..." />
        </SearchWrapper>
      </SearchBar>
      <Icons>
        <img src={cartIcon} alt="Cart" style={{ width: "24px", height: "24px", cursor: "pointer" }} />
        <img src={signupIcon} alt="Sign Up" style={{ width: "24px", height: "24px", cursor: "pointer" }} />
      </Icons>
    </HeaderWrapper>
  );
}

const HeaderWrapper = styled.header`
  display: flex;
  align-items: center;
  padding: 9px 62px;
  background-color: white;
  width: 90%;
  max-width: 1200px;
  margin: 0 auto;
`;

const Logo = styled.div`
  font-size: 32px;
  font-weight: 700;
  color: #000000;
  cursor: pointer;
`;

const Nav = styled.nav`
  flex-grow: 1;
  ul {
    list-style: none;
    display: flex;
    font-size:16px;
    gap: 24px;
    li {
      a {
        text-decoration: none;
        color: black;
      }
    }
  }
`;

const SearchBar = styled.div`
  display: flex;
  align-items: center;
`;

const SearchWrapper = styled.div`
  position: relative;
  display: flex;
  align-items: center;
`;

const SearchIcon = styled.img`
  position: absolute;
  left: 16px;
  width: 20px;
  height: 20px;
`;

const SearchBarInput = styled.input`
  padding: 12px 16px 12px 40px; /* Adds space for the icon */
  border-radius: 62px;
  border: 1px solid #ccc;
  width: 485px;
  color: #F0F0F0; /* Adjusted color for text */
  background-color: #F0F0F0;
  border:none;
`;

const Icons = styled.div`
  display: flex;
  align-items: center;
  gap: 15px;
  margin-left: 10px;
`;

export default Header;
