import React from 'react';
import styled from 'styled-components';
import crossIconImage from '../../assests/Frame (3).svg'; // Renamed import to avoid conflict

const TopBar = () => {
  return (
    <StyledTopBar>
      <span>
        Sign up and get 20% off your first order.
        <SignUpLink href="#signup">Sign Up Now</SignUpLink>
      </span>
      <CrossIcon src={crossIconImage} alt="cross" />
    </StyledTopBar>
  );
};

const StyledTopBar = styled.div`
  background-color: black;
  color: white;
  text-align: center;
  padding: 10px;
  font-size: 14px;
  position: relative; /* Added to position the cross icon */
`;

const CrossIcon = styled.img`
  position: absolute;
  right: 89px; /* Positioned to the right */
  top: 50%;
  transform: translateY(-50%); /* Centers the icon vertically */
  width: 20px;
  height: 20px;
  cursor: pointer; /* Optionally add a cursor style for better UX */
`;

// Define the styled component for the link
const SignUpLink = styled.a`
  color: white;
  font-weight: bold;
  text-decoration: none;
  margin-left: 5px;

  &:hover {
    text-decoration: underline;
  }
`;

export default TopBar;
