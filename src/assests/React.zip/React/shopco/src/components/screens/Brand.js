import React from "react";
import styled from "styled-components";
import  versa from "../../assests/versa.png";
import zara from "../../assests/zara-logo-1 1.png";
import gucci from "../../assests/gucci-logo-1 1.png";
import  pranda from "../../assests/prada-logo-1 1.png";
import calvinkelin from "../../assests/Group (1).png";

const Brand = () => {
  return (
    <Wrapper>
      <BrandContainer>
      <BrandImage src={versa} alt="brandversa"/>
        <BrandImage src={zara} alt="brandzara"/>
        <BrandImage src={gucci} alt="brandgucci"/>
        <BrandImage src={pranda} alt="brandprada"/>
        <BrandImage src={calvinkelin} alt="brandcalvinklin"/>
      </BrandContainer>
    </Wrapper>
  );
};

export default Brand;

// Styled-components
const Wrapper = styled.div`
  width: 100%;
  background-color: #000; /* Black background color */
  padding: 20px 0;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const BrandContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 91%;
`;

const BrandImage = styled.img`
   /* Set the width to 166.48px */
  height: auto;  /* Maintain the aspect ratio */
  cursor: pointer;
  transition: transform 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1); /* Slightly scale on hover */
  }
`;
