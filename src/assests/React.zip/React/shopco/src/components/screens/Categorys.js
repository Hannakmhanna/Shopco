import React from 'react';
import styled from 'styled-components';
import casualImg from '../../assests/assets/casual.png';
import formalImg from '../../assests/assets/formal.png';
import partyImg from '../../assests/assets/party.png';
import gymImg from '../../assests/assets/gym.png';

const Container = styled.div`
  background-color: #f5f5f5;
  padding: 20px;
  border-radius: 15px;
  width: 80%;
  margin: 86px auto;
`;

const Heading = styled.h2`
  text-align: center;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
`;

const Card = styled.div`
  position: relative;
  width: 100%;
  padding-top: 70%; /* This maintains a fixed aspect ratio (7:10) */
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  }
`;

const CardImage = styled.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover; /* Ensures the image covers the area while cropping excess */
`;

const CardLabel = styled.div`
  position: absolute;
  bottom: 10px;
  left: 10px;
  background-color: rgba(0, 0, 0, 0.6);
  color: #fff;
  padding: 5px 10px;
  border-radius: 5px;
  font-size: 16px;
`;

const dressStyles = [
  { label: 'Casual', img: casualImg },
  { label: 'Formal', img: formalImg },
  { label: 'Party', img: partyImg },
  { label: 'Gym', img: gymImg },
];

const DressStyleGrid = () => {
  return (
    <Container>
      <Heading>BROWSE BY DRESS STYLE</Heading>
      <Grid>
        {dressStyles.map((style, index) => (
          <Card key={index}>
            <CardImage src={style.img} alt={style.label} />
            <CardLabel>{style.label}</CardLabel>
          </Card>
        ))}
      </Grid>
    </Container>
  );
};

export default DressStyleGrid;
