import React, { useRef } from 'react';
import styled from 'styled-components';
import { Swiper, SwiperSlide } from 'swiper/react'; // Only import Swiper and SwiperSlide
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { FaStar } from 'react-icons/fa';
import ArrowButton1 from "../../assests/assets/arrow-down-bold 1.png";
import ArrowButton2 from "../../assests/assets/arrow-down-bold 2.png";

// Styled components
const Wrapper = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  width: 90%;
  padding: 40px 0;
`;

const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const Heading = styled.h2`
  font-size: 28px;
  font-weight: bold;
`;

const ReviewCard = styled.div`
  background-color: #fff;
  border-radius: 20px;
  padding: 20px;
  border: 1px solid #0000001A;
`;

const Stars = styled.div`
  color: #f5c518;
  display: flex;
  align-items: center;
  margin-bottom: 10px;
`;

const ReviewText = styled.p`
  font-size: 16px;
  line-height: 1.5;
  margin-bottom: 15px;
  font-weight: 400;
  color: #00000099;
`;

const ReviewerInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const ReviewerName = styled.h4`
  font-size: 20px;
  font-weight: 700;
  margin: 0;
`;

const ArrowImage = styled.img`
  width: 30px;
  height: 30px;
  cursor: pointer;
  transition: transform 0.3s;

  &:hover {
    transform: scale(1.1);
  }
`;

const ArrowContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
`;

const reviews = [
  {
    name: 'Sarah M.',
    text: "I'm blown away by the quality and style of the clothes by the quality and style of the clothes I received from Shop.co. From casual wear to elegant dresses, every piece I've bought has exceeded my expectations.",
    rating: 5,
  },
  {
    name: 'Alex K.',
    text: "Finding clothes that align with my personal style used to be a challenge until I discovered ShopCo. From casual wear to elegant dresses, every piece I've bought has exceeded my expectations.",
    rating: 5,
  },
  {
    name: 'James L.',
    text: "As someone who's always on the lookout for unique fashion pieces, I'm thrilled to have stumbled upon ShopCo. From casual wear to elegant dresses, every piece I've bought has exceeded my expectations.",
    rating: 5,
  },
];

const Reviews = () => {
  const swiperRef = useRef(null);  // Initialize the ref here
  
  // Define the handlePrevClick and handleNextClick functions
  const handlePrevClick = () => {
    if (swiperRef.current) {
      swiperRef.current.swiper.slidePrev();
    }
  };

  const handleNextClick = () => {
    if (swiperRef.current) {
      swiperRef.current.swiper.slideNext();
    }
  };

  return (
    <Wrapper>
      {/* Flex container for heading and arrow images */}
      <Container>
        <Heading>OUR HAPPY CUSTOMERS</Heading>
        {/* Arrow images aligned to the right */}
        <ArrowContainer>
          <ArrowImage 
            src={ArrowButton1} 
            alt="Arrow 1" 
            onClick={handlePrevClick} // Connect the button to the slidePrev method
          />
          <ArrowImage 
            src={ArrowButton2} 
            alt="Arrow 2" 
            onClick={handleNextClick} // Connect the button to the slideNext method
          />
        </ArrowContainer>
      </Container>

      {/* Swiper component with pagination */}
      <Swiper
        ref={swiperRef}  // Attach the ref to Swiper
        spaceBetween={20}
        slidesPerView={3}
        pagination={{ clickable: true }} // Enable pagination
        navigation={true} // Enable navigation (use default navigation buttons)
        breakpoints={{
          320: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 3 },
        }}
      >
        {reviews.map((review, index) => (
          <SwiperSlide key={index}>
            <ReviewCard>
              <ReviewerInfo>
                <Stars>
                  {[...Array(review.rating)].map((_, i) => (
                    <FaStar key={i} />
                  ))}
                </Stars>
                <ReviewerName>{review.name}</ReviewerName>
              </ReviewerInfo>
              <ReviewText>{review.text}</ReviewText>
            </ReviewCard>
          </SwiperSlide>
        ))}
      </Swiper>
    </Wrapper>
  );
};

export default Reviews;
