import React from "react";
import styled from 'styled-components';
import SampleImage from "../../assests/Rectangle 2.png";
import vector from "../../assests/Vector (5).png";
import vector2 from "../../assests/Vector (6).png";



const SpotLight = () => {
  return (
    
     
      <Wrapper>
        <Container>
          <LeftContent>
            <Title>FIND CLOTHES THAT MATCHES YOUR STYLE</Title>
            <Subtitle>
              Browse through our diverse range of meticulously crafted garments,
              designed to bring out your individuality and cater to your sense of style.
            </Subtitle>
            <Button>Shop Now</Button>
            <StatsContainer>
              <StatBox>
                <StatNumber>200+</StatNumber>
                <StatText>International Brands</StatText>
              </StatBox>
              <StatBox>
                <StatNumber>2,000+</StatNumber>
                <StatText>High-Quality Products</StatText>
              </StatBox>
              <StatBox>
                <StatNumber>30,000+</StatNumber>
                <StatText>Happy Customers</StatText>
              </StatBox>
            </StatsContainer>
          </LeftContent>

          {/* Right Image Section */}
          <RightImage>
            <Vector src={vector} alt="vector" />
            <MainImage src={SampleImage} alt="main" />
            <Vector2 src={vector2} alt="vector2" />
          </RightImage>
        </Container>
      </Wrapper>
    
  );
};

// Styled Components
const Wrapper = styled.div`

  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #F2F0F1;

`;

const Container = styled.section`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0px 20px;
  gap: 40px;
  width: 90%;
  max-width: 1200px;

  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
  }
`;

const LeftContent = styled.div`
  flex: 1;
  max-width: 50%;
  padding-right: 20px;
`;

const RightImage = styled.div`
  flex: 1;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
`;

const Vector = styled.img`
   position: absolute;
  bottom: 48%;
  right: 85%;
  width: 80px;
  height: auto;
  z-index: 3;
`;

const MainImage = styled.img`
  width: 500px;
  height: 718px;
  border-radius: 10px;
 
`;

const Vector2 = styled.img`
 
  position: absolute;
  top: 7%;
  left: 75%;
  width: 100px;
  height: auto;
  z-index: 2;
`;

const Title = styled.h1`
  font-size: 59px;
  font-weight: 700;
  margin-bottom: 20px;
`;

const Subtitle = styled.p`
  font-size: 16px;
  color: #555;
  margin-bottom: 40px;
  width: 92%;
`;

const Button = styled.button`
  padding: 16px 54px;
  background-color: #000000;
  color: #fff;
  font-size: 16px;
  border: none;
  border-radius: 62px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #333;
  }
`;

const StatsContainer = styled.div`
  display: flex;
  gap: 32px;
  margin-top: 30px;

  @media (max-width: 768px) {
    justify-content: center;
  }
`;

const StatBox = styled.div`
  text-align: center;
  position: relative;

  &::before {
    content: "";
    position: absolute;
    right: 169px;
    top: 39%;
    height: 47%;
    width: 1px;
    background-color: #0000001a;
  }

  &:first-child::before {
    display: none;
  }
`;

const StatNumber = styled.h2`
  font-size: 40px;
  font-weight: bold;
  margin-bottom: -12px;
`;

const StatText = styled.p`
  font-size: 16px;
  color: #777;
`;

export default SpotLight;
