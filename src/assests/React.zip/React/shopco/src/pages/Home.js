import React from 'react';
import TopBar from '../components/includes/TopBar';
import Header from '../components/includes/Header';
import  SpotLight from '../components/screens/Spotlight';
import Brand from '../components/screens/Brand';
import Products from '../components/screens/Product';
import ProductsItem from '../components/screens/ProductsItem';
import  Categorys from '../components/screens/Categorys';
import Reviews from '../components/screens/Reviews';

function Home() {
  return (
    <div>
        <TopBar/>
        <Header/>
        <SpotLight/>
        <Brand/>
        <Products/>
        <ProductsItem/>
        <Categorys/>
        <Reviews/>
    </div>
  )
}

export default Home;